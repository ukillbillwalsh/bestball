const DATA_URL = (typeof window!=='undefined' && window.BESTBALL_URL) || './bestball.json';
// Scoped per-draft (via a draftId passed in from underdog-watcher.js as a
// query param) so "drafted"/"mine" state from one draft never bleeds into
// a different one \u2014 previously this was a single shared key across every
// draft ever opened, which caused leftover test/experiment state to show
// up as false "drafted" markers in unrelated later drafts.
const DRAFT_ID = (typeof window!=='undefined' && new URLSearchParams(window.location.search).get('draftId')) || '';
const LS_KEY = 'cfb_draft_companion_v1' + (DRAFT_ID ? ('_' + DRAFT_ID) : '');

// BYE_WEEKS overrides whatever bye each player has in bestball.json.
// Keys are team abbreviations OR full team names (checked first — needed
// because the pipeline truncates e.g. "North Carolina State Wolfpack" to
// "NORTH", which collides with three other programs).  Values may be one
// week or an array: Week 0 teams play Aug 29 and get TWO byes.
// Verified against official 2026 schedule releases (Jan-May 2026).
const BYE_WEEKS = {
  'UNC':  [1, 4],   // W0 vs TCU (Dublin); open Sep 5 + Sep 26
  'TCU':  [1, 6],   // W0 vs UNC (Dublin); open Sep 5 + Oct 10
  'USC':  [7, 10],  // W0 vs SJSU; open Oct 17 + Nov 7
  'UVA':  [1, 10],  // W0 vs NC State (Brazil); open Sep 5 + Nov 7
  'STAN': [2, 10],  // W0 vs Hawaii; open Sep 12 + Nov 7
  'FSU':  [2, 8],   // W0 vs New Mexico State; open Sep 12 + Oct 24
  'North Carolina State Wolfpack': [1, 7],  // W0 vs UVA (Brazil); open Sep 5 + Oct 17
};

// A player's byes as an array, however they arrived (override, p.byes, p.bye).
function byesOf(p){
  if(Array.isArray(p.byes) && p.byes.length) return p.byes;
  if(p.bye != null) return [p.bye];
  return [];
}

// TEAM_LOGOS is baked in by fetch_team_logos.py.  Keys are team abbreviations
// matching the `team` field in bestball.json; values are ESPN CDN URLs.
const TEAM_LOGOS = {};

// Manual fixes checked BEFORE TEAM_LOGOS.  Two problems in the pipeline map:
// (1) several teams are missing entirely (keyed by abbreviation below), and
// (2) 5-letter truncation collisions — "NORTH" covers NC State AND North
// Dakota State AND two more programs, so one abbrev-keyed logo can't be right
// (keyed by teamFull below, which is collision-proof).
const ESPN_LOGO = id => `https://a.espncdn.com/i/teamlogos/ncaa/500-dark/${id}.png`;
const LOGO_FIXES = {
  // Missing from the pipeline map
  'WSH':  ESPN_LOGO(264),   // Washington Huskies
  'TAMU': ESPN_LOGO(245),   // Texas A&M Aggies
  'UF':   ESPN_LOGO(57),    // Florida Gators
  'IND':  ESPN_LOGO(84),    // Indiana Hoosiers
  'SCAR': ESPN_LOGO(2579),  // South Carolina Gamecocks
  'NW':   ESPN_LOGO(77),    // Northwestern Wildcats
  // Truncation collisions / wrong logos, keyed by full name
  'North Carolina State Wolfpack': ESPN_LOGO(152),
  'North Dakota State Bison':      ESPN_LOGO(2449),
  'South Dakota State Jackrabbits':ESPN_LOGO(2571),
  'Florida Atlantic Owls':         ESPN_LOGO(2226),
  'Indiana State Sycamores':       ESPN_LOGO(282),
  'Texas State Bobcats':           ESPN_LOGO(326),
};
// Abbreviations shared by multiple programs: never trust the abbrev-keyed
// pipeline logo for these — resolve by full name or show nothing, since no
// logo beats the wrong team's logo.
const AMBIGUOUS_TEAM_ABBRS = new Set(['NORTH','SOUTH']);

// Accepts a player object (preferred — enables full-name resolution) or a
// bare abbreviation string for older call sites.
function teamLogo(pOrTeam, sm){
  const isObj = !!pOrTeam && typeof pOrTeam === 'object';
  const team  = isObj ? pOrTeam.team : pOrTeam;
  const full  = isObj ? pOrTeam.teamFull : null;
  // TEAM_LOGOS may be keyed by abbreviation (fetch_team_logos.py bake, old
  // pipeline) or by full school name (fix_logos.py in the daily bat).
  // Accept both: manual LOGO_FIXES wins, then full-name, then abbrev.
  let url = (full && (LOGO_FIXES[full] || TEAM_LOGOS[full])) || null;
  if(!url && team){
    if(LOGO_FIXES[team]) url = LOGO_FIXES[team];
    else if(!AMBIGUOUS_TEAM_ABBRS.has(team)) url = TEAM_LOGOS[team];
  }
  if(!url) return '';
  const cls = sm ? 'team-logo sm' : 'team-logo';
  // onerror hides broken/missing logos gracefully; loading=lazy defers offscreen loads
  return `<img src="${url}" class="${cls}" alt="${team}" loading="lazy" onerror="this.style.display='none'">`;
}

let BESTBALL = {players:[], updated:"", count:0};
let draftState = loadState();
let sortKey = 'adp', sortDir = 1;
let posFilter = 'ALL';
let query = '';

// Every draft starts clean: state is scoped per-draft via LS_KEY, and any
// OTHER draft's leftover state (finished drafts, old experiments) is purged
// the moment a new companion mounts.  Also clears keys from removed features
// (hidden positions) so nothing stale lingers.
(function purgeStaleState(){
  try{
    for(let i = localStorage.length - 1; i >= 0; i--){
      const k = localStorage.key(i);
      if(k && k.indexOf('cfb_draft_companion_v1') === 0 && k !== LS_KEY){
        localStorage.removeItem(k);
      }
    }
    localStorage.removeItem('cfb_hidden_pos_v1');
  }catch(e){}
})();

function loadState(){
  try{
    const raw = localStorage.getItem(LS_KEY);
    if(!raw) return {drafted:[], mine:[], selected:null};
    const o = JSON.parse(raw);
    return {drafted: o.drafted||[], mine: o.mine||[], selected: o.selected||null};
  }catch(e){ return {drafted:[], mine:[], selected:null}; }
}
function saveState(){
  try{ localStorage.setItem(LS_KEY, JSON.stringify(draftState)); }catch(e){}
}
const isDrafted = id => draftState.drafted.includes(id) || draftState.mine.includes(id);
const isMine    = id => draftState.mine.includes(id);
const isSelected= id => draftState.selected === id;

function toggleSelected(id){
  draftState.selected = (draftState.selected === id) ? null : id;
  saveState();
  render();
}

function toggleDrafted(id){
  if(isMine(id)){
    draftState.mine    = draftState.mine.filter(x=>x!==id);
    draftState.drafted = draftState.drafted.filter(x=>x!==id);
  } else if(draftState.drafted.includes(id)){
    draftState.drafted = draftState.drafted.filter(x=>x!==id);
  } else {
    draftState.drafted.push(id);
  }
  saveState(); render();
}
function toggleMine(id){
  if(isMine(id)){
    draftState.mine    = draftState.mine.filter(x=>x!==id);
    draftState.drafted = draftState.drafted.filter(x=>x!==id);
  } else {
    if(!draftState.mine.includes(id)) draftState.mine.push(id);
    draftState.drafted = draftState.drafted.filter(x=>x!==id);
  }
  saveState(); render();
}

// Auto-detection can mark the wrong player.  There was no way to undo that
// from the UI: drafted players are filtered off the board, so the \u2605 toggle
// that would normally clear them is unreachable.  This moves a player out of
// "mine" but leaves them drafted, which is the true state - somebody took
// them, just not you.
function unmine(id){
  if(!isMine(id)) return;
  draftState.mine = draftState.mine.filter(x=>x!==id);
  if(!draftState.drafted.includes(id)) draftState.drafted.push(id);
  saveState(); render();
}

function render(){
  const body = document.getElementById('dbody');

  let rows = BESTBALL.players.filter(p=>{
    if(posFilter!=='ALL' && p.pos!==posFilter) return false;
    if(query){
      const q = query.toLowerCase();
      const hit = p.name.toLowerCase().includes(q)
               || (p.team||'').toLowerCase().includes(q)
               || (p.teamFull||'').toLowerCase().includes(q);
      if(!hit) return false;
    }
    // Drafted players always drop off automatically \u2014 driven by the live
    // Underdog sync, not a manual toggle. This now applies whether you or
    // someone else drafted them: "mine" is still tracked separately for
    // Best Stacking, it just no longer keeps a drafted player visible here.
    if(isDrafted(p.id)) return false;
    return true;
  });

  rows.sort((a,b)=>{
    let x=a[sortKey], y=b[sortKey];
    if(x==null && y==null) return 0;
    if(x==null) return 1;
    if(y==null) return -1;
    if(typeof x==='string') return sortDir*x.localeCompare(y);
    return sortDir*(x-y);
  });

  const cap = 500;
  const shown = rows.slice(0, cap);
  body.innerHTML = shown.map(p=>{
    const drafted = isDrafted(p.id);
    const mine    = isMine(p.id);
    const selected= isSelected(p.id);
    const cls     = [
      mine     ? 'mine'     : '',
      !mine && drafted ? 'drafted' : '',
      selected ? 'selected' : '',
    ].filter(Boolean).join(' ');
    return `<tr class="${cls}" data-id="${p.id}">
      <td><button class="queue-btn" data-queue="${p.id}" title="Add to Underdog queue">★</button></td>
      <td class="adp-cell">${p.adp==null?'—':p.adp}</td>
      <td class="num">${p.myRank==null?'—':p.myRank}</td>
      <td class="l">${teamLogo(p)}<span class="pname-d">${p.name}</span></td>
      <td><span class="posbadge pos-${p.pos}">${p.pos}</span></td>
      <td style="color:var(--muted);font-family:var(--mono);font-size:12px">${p.team||'—'}</td>
      <td class="num">${p.proj==null?'—':p.proj}</td>
      <td class="num" style="color:var(--muted)">${byesOf(p).length?byesOf(p).map(w=>'W'+w).join('·'):'—'}</td>
    </tr>`;
  }).join('');

  if(rows.length > shown.length){
    body.insertAdjacentHTML('beforeend',
      `<tr><td colspan="8" style="padding:14px;text-align:center;color:var(--dim);font-family:var(--mono);font-size:11px">Showing first ${shown.length} of ${rows.length} matches.  Narrow with a filter or search to see the rest.</td></tr>`);
  }
  renderRoster(); renderBestAvailable(); renderStacks(); renderByes();
  // Partners + QB Stacks live in the Partners tab; refresh only while open.
  if(document.querySelector('.tab-pane[data-tab-content="partners"].on')){
    renderPartners(); renderQbStacks();
  }
}

// Sends a request up to underdog-watcher.js (running on the actual Underdog
// page) asking it to find this player's row and click their queue/star
// button \u2014 this iframe can't touch that DOM directly since it's a
// different origin, so postMessage is the bridge.
function queuePlayer(id){
  const p = BESTBALL.players.find(x=>x.id===id);
  if(!p) return;
  window.parent.postMessage({
    type: 'cfb-queue-player',
    name: p.name,
    lastName: extractLastName(p.name), // same Jr/Sr/II/III stripping Bruce's sync logic already uses
    team: p.team || null,
    pos: p.pos || null,
  }, '*');
}

// Your own picks, as detected by underdog-watcher.js (snake-draft math against
// your seat) or set by hand with the ★.  Byes are shown per player here and
// aggregated in the Bye Weeks panel below.
function renderRoster(){
  const mine = BESTBALL.players.filter(p=>isMine(p.id));

  // Two counters: one on the Board / My Team switch, one on the panel heading.
  ['rosterCount','rosterCountPanel'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.textContent = mine.length;
  });

  const counts = {QB:0,RB:0,WR:0,TE:0};
  mine.forEach(p=>{ if(counts[p.pos]!==undefined) counts[p.pos]++; });
  const countsEl = document.getElementById('poscounts');
  if(countsEl){
    countsEl.innerHTML =
      ['QB','RB','WR','TE'].map(pos=>
        `<div class="poscount ${pos}"><div class="lbl">${pos}</div><div class="num">${counts[pos]}</div></div>`).join('')
      + `<div class="poscount TOT"><div class="lbl">Tot</div><div class="num">${mine.length}</div></div>`;
  }

  const listEl = document.getElementById('rosterlist');
  if(!listEl) return;

  // Bye clusters get flagged inline so a crowded week is visible while you're
  // looking at the roster, not only in the grid underneath.
  const byeCt = {};
  mine.forEach(p=>{ byesOf(p).forEach(bw=>{ byeCt[bw] = (byeCt[bw]||0)+1; }); });

  const sorted = [...mine].sort((a,b)=>{
    const o = {QB:0,RB:1,WR:2,TE:3};
    return (o[a.pos]??9) - (o[b.pos]??9) || (a.adp??999) - (b.adp??999);
  });
  listEl.innerHTML = sorted.length===0
    ? `<div class="rosterempty">No picks yet.  Your picks land here automatically as the draft runs, or tap ★ on any player to add them by hand.</div>`
    : sorted.map(p=>{
        const pb = byesOf(p);
        const clusterW = pb.find(bw => byeCt[bw] >= 3);
        const cluster = clusterW != null;
        return `<div class="ritem">
        <span class="ri-pos pos-${p.pos}">${p.pos}</span>
        <span class="ri-name">${teamLogo(p, true)}${p.name}</span>
        <span class="ri-team">${p.team||''}</span>
        <span class="ri-bye${cluster?' conflict':''}" title="${cluster?`${byeCt[clusterW]} of your picks are off in W${clusterW}`:''}">${pb.length?pb.map(w=>'W'+w).join('·'):'—'}</span>
        <button class="ri-x" data-unmine="${p.id}" title="Not my pick">&times;</button>
      </div>`;
      }).join('');
}

// One column per drafted QB: the correlation pieces you already own on that
// QB's team, then the best-projected WR/TE still on the board there.  This is
// the at-a-glance "what does each of my stacks need" view that sits under the
// board during a draft; the deeper tap-to-preview partner tool lives in its
// own tab now.
function renderQbStacks(){
  const el = document.getElementById('qbstacks');
  if(!el) return;
  const players = BESTBALL.players || [];

  const myQBs = players
    .filter(p => isMine(p.id) && p.pos === 'QB' && p.team)
    .sort((a,b) => (a.myRank ?? 9999) - (b.myRank ?? 9999));

  if(myQBs.length === 0){
    el.innerHTML = `<div class="rosterempty">No QBs drafted yet.  Draft a QB and a stack column appears here showing who you've paired with him and the best-projected pass-catchers still available on his team.</div>`;
    return;
  }

  const drafted = new Set(draftState.drafted);
  const POS_SORT = {QB:0,RB:1,WR:2,TE:3};
  // "Best projected" is the explicit ask, so proj leads.  Players with no proj
  // sink rather than jumping the queue on a missing value.
  const projOf = p => (typeof p.proj === 'number' && isFinite(p.proj)) ? p.proj : -Infinity;

  el.innerHTML = myQBs.map(qb => {
    const team = qb.team;

    const owned = players
      .filter(p => p.team === team && isMine(p.id) && p.id !== qb.id)
      .sort((a,b) => (POS_SORT[a.pos]??9) - (POS_SORT[b.pos]??9) || projOf(b) - projOf(a));

    const avail = pos => players
      .filter(p => p.team === team && p.pos === pos && !drafted.has(p.id) && !isMine(p.id))
      .sort((a,b) => projOf(b) - projOf(a));

    const picks = [...avail('WR').slice(0,3), ...avail('TE').slice(0,2)];

    const ownedHtml = owned.length
      ? owned.map(p => `<div class="qs-row owned">
          <span class="posbadge pos-${p.pos}">${p.pos}</span>
          <span class="qs-nm">${p.name}</span>
          <span class="qs-proj">${typeof p.proj==='number'?Math.round(p.proj):'—'}</span>
        </div>`).join('')
      : `<div class="qs-empty">Just the QB so far</div>`;

    const availHtml = picks.length
      ? picks.map(p => `<div class="qs-row avail" data-star="${p.id}" title="Mark ${p.name} as yours">
          <span class="posbadge pos-${p.pos}">${p.pos}</span>
          <span class="qs-nm">${p.name}</span>
          <span class="qs-proj">${typeof p.proj==='number'?Math.round(p.proj):'—'}</span>
        </div>`).join('')
      : `<div class="qs-empty">No WR/TE left on ${team}</div>`;

    const qbProj = typeof qb.proj==='number' ? Math.round(qb.proj) : null;

    return `<div class="qs-col">
      <div class="qs-head">
        <span class="posbadge pos-QB">QB</span>
        <span class="qs-qb">${teamLogo(qb, true)}${qb.name}</span>
        <span class="qs-team">${team}${qbProj!=null?` · ${qbProj}`:''}</span>
      </div>
      <div class="qs-lbl">Your stack <span>${owned.length+1}</span></div>
      <div class="qs-list">${ownedHtml}</div>
      <div class="qs-lbl">Best available</div>
      <div class="qs-list">${availHtml}</div>
    </div>`;
  }).join('');
}

function renderStacks(){
  const mine = BESTBALL.players.filter(p=>isMine(p.id));
  const byTeam = {};
  mine.forEach(p=>{ if(!p.team) return; (byTeam[p.team] = byTeam[p.team]||[]).push(p); });
  const stacks = Object.entries(byTeam).filter(([_,arr])=>arr.length>=2).sort((a,b)=>b[1].length-a[1].length);

  const el = document.getElementById('stacks');
  if(!el) return;
  if(stacks.length===0){
    el.innerHTML = `<div class="rosterempty">No stacks yet.  A stack forms when you own 2+ players from the same team.</div>`;
    return;
  }
  el.innerHTML = stacks.map(([team, arr])=>{
    const hasQB = arr.some(p=>p.pos==='QB');
    const hasCatcher = arr.some(p=>['WR','TE','RB'].includes(p.pos));
    const isQbStack = hasQB && hasCatcher;
    const tag = isQbStack ? 'QB STACK' : '';
    const players = arr.sort((a,b)=>({QB:0,RB:1,WR:2,TE:3}[a.pos]??9) - ({QB:0,RB:1,WR:2,TE:3}[b.pos]??9))
                       .map(p=>`${p.pos} ${p.name}`).join(' · ');
    return `<div class="stack ${isQbStack?'qb-stack':''}">
      <div class="stk-head">${team} <span style="color:var(--dim);font-size:11px">${arr.length} picks</span> <span class="stk-tag">${tag}</span></div>
      <div class="stk-players">${players}</div>
    </div>`;
  }).join('');
}

function renderPartners(){
  const sel       = draftState.selected;
  const summaryEl = document.getElementById('partnersSummary');
  const listEl    = document.getElementById('partners');
  if(!summaryEl || !listEl) return;

  if(!sel){
    summaryEl.innerHTML = `<span style="color:var(--dim)">Tap any row in the player table to preview that player's stacking partners.</span>`;
    listEl.innerHTML = '';
    return;
  }

  const player = BESTBALL.players.find(p => p.id === sel);
  if(!player){
    summaryEl.innerHTML = `<span style="color:var(--dim)">Selected player not found in the current pool.</span>`;
    listEl.innerHTML = '';
    return;
  }
  if(!player.team){
    summaryEl.innerHTML = `<span style="color:var(--dim)">${player.name} has no team data, can't suggest partners.</span>`;
    listEl.innerHTML = '';
    return;
  }

  // Rank prefers Bruce's myRank, falls back to ADP
  const rank = p => p.myRank != null ? p.myRank
                  : p.adp    != null ? p.adp
                  : Infinity;

  const drafted = new Set(draftState.drafted);
  const team    = player.team;

  const candidates = BESTBALL.players.filter(p =>
    p.team === team &&
    p.id !== sel &&
    !drafted.has(p.id) &&
    !isMine(p.id) &&
    rank(p) !== Infinity
  );

  // Position priority depends on the selected player's slot
  const isQB   = player.pos === 'QB';
  const isPass = player.pos === 'WR' || player.pos === 'TE';
  const posOrder = isQB
    ? {WR:0, TE:1, RB:2, QB:3}       // chasing his catchers
    : isPass
      ? {QB:0, WR:1, TE:2, RB:3}     // get the QB
      : {QB:0, WR:1, TE:2, RB:3};    // RB anchor — still grab QB first

  candidates.sort((a, b) =>
    (posOrder[a.pos] ?? 9) - (posOrder[b.pos] ?? 9) ||
    rank(a) - rank(b)
  );

  const top = candidates.slice(0, 8);

  // Bye-cluster context: count of YOUR picks (plus the selected player if not
  // already yours) sharing each bye, so a "conflict" warning means picking
  // this candidate too would push the cluster to 3+.
  const byeCounts = {};
  BESTBALL.players.filter(p=>isMine(p.id)).forEach(p=>{
    byesOf(p).forEach(bw=>{ byeCounts[bw] = (byeCounts[bw]||0)+1; });
  });
  if(!isMine(sel)){
    byesOf(player).forEach(bw=>{ byeCounts[bw] = (byeCounts[bw]||0)+1; });
  }

  // Selected player summary header
  const selRk = player.myRank != null ? `MY ${player.myRank}`
              : player.adp    != null ? `ADP ${player.adp}`
              : 'UR';
  const ownership = isMine(sel)
    ? ` <span style="color:var(--accent);font-weight:600">★ YOURS</span>`
    : drafted.has(sel)
      ? ` <span style="color:var(--red);font-weight:600">DRAFTED</span>`
      : '';
  summaryEl.innerHTML = `Showing partners for <b>${player.pos} ${player.name}</b> · ${team} · ${selRk}${ownership}`;

  if(top.length === 0){
    listEl.innerHTML = `<div class="partner-empty">No available teammates with rank data on ${team}.</div>`;
    return;
  }

  const rows = top.map(p=>{
    let tag = '';
    if(isQB   && (p.pos==='WR' || p.pos==='TE')) tag = 'QB stack';
    else if(!isQB && p.pos==='QB')               tag = 'pair the QB';
    else if(isQB && p.pos==='RB')                tag = 'team correlation';
    else if(p.pos==='WR' || p.pos==='TE')        tag = '2nd skill';

    const rk      = p.myRank != null ? `MY ${p.myRank}` : `ADP ${p.adp}`;
    const pb      = byesOf(p);
    const byeNote = pb.length ? pb.map(w=>'W'+w).join('·') : '—';
    const confW   = pb.find(bw => byeCounts[bw] >= 2);
    const conflict = confW != null ? 'conflict' : '';
    const byeTitle = conflict ? `would push your bye cluster on W${confW} to ${byeCounts[confW]+1}` : '';

    return `<div class="partner-row" data-star="${p.id}">
      <span class="posbadge pos-${p.pos}">${p.pos}</span>
      <span class="nm">${teamLogo(p, true)}${p.name}</span>
      <span class="adp">${rk}</span>
      <span class="bye ${conflict}" title="${byeTitle}">${byeNote}</span>
      ${tag ? `<span class="stk-tag">${tag.toUpperCase()}</span>` : ''}
    </div>`;
  }).join('');

  listEl.innerHTML = `<div class="partner-team">
    <div class="partner-head">
      <span class="team">${team}</span>
      <span class="anchor">${top.length} available</span>
    </div>
    <div class="partner-list">${rows}</div>
  </div>`;
}

// Minimal bye counter: one chip per week you have picks off ("W7 ×3"),
// coloured amber when a cluster forms and red when it gets dangerous.
// Tooltip carries the per-position breakdown the old table used to show.
function renderByes(){
  const el = document.getElementById('byestrip');
  if(!el) return;
  const mine = BESTBALL.players.filter(p=>isMine(p.id));

  const byWeek = {};   // week -> {QB, RB, WR, TE, TOTAL}
  mine.forEach(p=>{
    byesOf(p).forEach(bw=>{
      if(!byWeek[bw]) byWeek[bw] = {QB:0, RB:0, WR:0, TE:0, TOTAL:0};
      if(byWeek[bw][p.pos] !== undefined) byWeek[bw][p.pos]++;
      byWeek[bw].TOTAL++;
    });
  });

  const weeks = Object.keys(byWeek).map(Number).sort((a,b)=>a-b);
  if(weeks.length === 0){ el.hidden = true; el.innerHTML = ''; return; }

  const chips = weeks.map(w=>{
    const c = byWeek[w];
    const maxPos = Math.max(c.QB, c.RB, c.WR, c.TE);
    const cls = (maxPos >= 3 || c.TOTAL >= 4) ? ' danger'
              : (maxPos >= 2 || c.TOTAL >= 2) ? ' warn'
              : '';
    const detail = ['QB','RB','WR','TE'].filter(p=>c[p]>0).map(p=>`${c[p]} ${p}`).join(', ');
    return `<span class="byechip${cls}" title="${detail} off in W${w}"><b>W${w}</b> ×${c.TOTAL}</span>`;
  }).join('');
  el.innerHTML = `<span class="bslbl">Byes</span>${chips}`;
  el.hidden = false;
}

// ================ BEST AVAILABLE ================
function renderBestAvailable(){
  const el = document.getElementById('bestavail');
  if(!el) return;
  const players = BESTBALL.players || [];
  const drafted = new Set(draftState.drafted);
  const mine    = players.filter(p=>isMine(p.id));

  // Soft caps - don't suggest more of a position you've already loaded up
  const POS_CAP = {QB:3, RB:6, WR:9, TE:2};
  const myPosCt = {QB:0, RB:0, WR:0, TE:0};
  mine.forEach(p=>{ if(myPosCt[p.pos] !== undefined) myPosCt[p.pos]++; });

  // Bye cluster context for the soft penalty
  const byeCt = {};
  mine.forEach(p=>{ byesOf(p).forEach(bw=>{ byeCt[bw] = (byeCt[bw]||0) + 1; }); });

  // Late-draft kicker: penalty grows with roster size
  const rosterSize = mine.length;
  const byePenaltyWeight = rosterSize >= 12 ? 30 : rosterSize >= 8 ? 12 : 0;

  const rank = p => p.myRank != null ? p.myRank
                  : p.adp    != null ? p.adp
                  : Infinity;

  const candidates = players
    .filter(p => !drafted.has(p.id) && !isMine(p.id) && rank(p) !== Infinity)
    // Follows the QB/RB/WR/TE chips so you can ask "best available RB" directly
    // rather than reading past positions you're already full at.
    .filter(p => posFilter === 'ALL' || p.pos === posFilter)
    // Soft caps only apply to the unfiltered view — if you've explicitly asked
    // for a position, show it even if you're past the cap.
    .filter(p => posFilter !== 'ALL' || !POS_CAP[p.pos] || myPosCt[p.pos] < POS_CAP[p.pos])
    .map(p => {
      const base = rank(p);
      const pb = byesOf(p);
      const existingOnBye = pb.length ? Math.max(...pb.map(bw => byeCt[bw] || 0)) : 0;
      let penalty = 0;
      if(existingOnBye >= 2) penalty = byePenaltyWeight;        // would push to 3+
      else if(existingOnBye === 1) penalty = byePenaltyWeight / 2;
      return { p, score: base + penalty, base, existingOnBye };
    })
    .sort((a,b) => a.score - b.score)
    .slice(0, 5);

  if(candidates.length === 0){
    el.innerHTML = `<div class="sugempty">No available players with rank data${posFilter==='ALL'?'':' at '+posFilter}.</div>`;
    return;
  }

  el.innerHTML = candidates.map(c => {
    const p = c.p;
    const rk  = p.myRank != null ? `MY ${p.myRank}` : `ADP ${p.adp}`;
    const pb  = byesOf(p);
    const byeNote = pb.length ? pb.map(w=>'W'+w).join('·') : '—';
    const conflict = c.existingOnBye >= 2 ? 'conflict' : '';
    const confW = pb.find(bw => (byeCt[bw] || 0) >= 2);
    const title = c.existingOnBye >= 2 ? `would push your bye cluster on W${confW} to ${c.existingOnBye + 1}` : `Mark ${p.name} as yours`;
    return `<div class="sugrow" data-star="${p.id}" title="${title}">
      <span class="posbadge pos-${p.pos}">${p.pos}</span>
      <span class="nm">${teamLogo(p, true)}${p.name}<span class="tm">${p.team || ''}</span></span>
      <span class="rk">${rk}</span>
      <span class="bye ${conflict}">${byeNote}</span>
    </div>`;
  }).join('');
}

// ================ TABS ================
function activateTab(name){
  document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on', t.dataset.tab===name));
  document.querySelectorAll('.tab-pane').forEach(p=>p.classList.toggle('on', p.dataset.tabContent===name));
  if(name==='partners'){ renderPartners(); renderQbStacks(); }
}
document.querySelectorAll('.tab').forEach(t=>{
  t.onclick = ()=> activateTab(t.dataset.tab);
});

// ================ BOARD / MY TEAM SUB-VIEW ================
// Only does anything below 1000px, where the two columns can't sit side by
// side.  Above that a media query forces both panes visible and hides the
// switch, so this state is harmless either way.  Persisted so a mid-draft
// reload doesn't bounce you back to the board.
const VIEW_KEY = 'cfb_draft_view_v1';
function activateView(name){
  document.querySelectorAll('.subtab').forEach(b=>b.classList.toggle('on', b.dataset.view===name));
  document.querySelectorAll('[data-view-pane]').forEach(p=>p.classList.toggle('on', p.dataset.viewPane===name));
  try{ localStorage.setItem(VIEW_KEY, name); }catch(e){}
}
document.querySelectorAll('.subtab').forEach(b=>{
  b.onclick = ()=> activateView(b.dataset.view);
});
try{
  const saved = localStorage.getItem(VIEW_KEY);
  if(saved === 'myteam') activateView('myteam');
}catch(e){}

// ================ SYNC DRAFTED FROM UNDERDOG ================
function normalizeName(name){
  if(!name) return '';
  let n = name.toLowerCase().trim();
  n = n.replace(/[^a-z0-9 ]/g, '');               // strip punctuation, keep spaces
  let parts = n.split(/\s+/).filter(Boolean);
  if(parts.length && ['jr','sr','ii','iii','iv'].includes(parts[parts.length-1])){
    parts = parts.slice(0, -1);
  }
  return parts.join('');
}

function buildNameIndex(){
  const idx = {};
  (BESTBALL.players || []).forEach(p=>{
    const k = normalizeName(p.name);
    if(!k) return;
    (idx[k] = idx[k] || []).push(p);
  });
  return idx;
}

// Extract the actual last name from "First Middle Last [Jr/Sr/III]"
function extractLastName(fullName){
  if(!fullName) return '';
  let parts = fullName.trim().split(/\s+/);
  const suffixes = ['jr','sr','ii','iii','iv'];
  if(parts.length > 1){
    const tail = parts[parts.length-1].toLowerCase().replace(/\./g, '');
    if(suffixes.includes(tail)) parts = parts.slice(0, -1);
  }
  return parts[parts.length - 1] || '';
}

function lastNameKey(s){
  return (s || '').toLowerCase().replace(/[^a-z]/g, '');
}

function buildLastNameIndex(){
  const idx = {};
  (BESTBALL.players || []).forEach(p=>{
    const key = lastNameKey(extractLastName(p.name));
    if(!key) return;
    (idx[key] = idx[key] || []).push(p);
  });
  return idx;
}

// Parse Underdog's packed format: "K. LacyRB - MISS" → {initial:"K", lastName:"Lacy", pos:"RB", team:"MISS"}
// Also tolerates: multi-letter initials ("A.J. Brown..."), middle/Jr in last name,
// and either hyphen or middle-dot as separator.
const PICK_REGEX = /^([A-Z](?:\.[A-Z])*)\.\s+(.+?)(QB|RB|WR|TE|K|D\/ST)[\s\-\u00b7]+([A-Z]+)\s*$/;
function parseDraftedLine(line){
  if(!line) return null;
  const m = line.trim().replace(/\s+/g, ' ').match(PICK_REGEX);
  if(!m) return null;
  return { initial: m[1], lastName: m[2].trim(), pos: m[3], team: m[4], raw: line };
}

// Score-based match: team > position > first-initial.  Returns the best player,
// or null if no last-name candidates at all.
function matchParsedPick(parsed, lastIdx){
  const lastClean = extractLastName(parsed.lastName);   // strips trailing Jr/Sr/II/III
  const candidates = lastIdx[lastNameKey(lastClean)] || [];
  if(candidates.length === 0) return null;
  if(candidates.length === 1) return candidates[0];

  const initialChar = parsed.initial[0];
  const scored = candidates.map(p => {
    let s = 0;
    if(p.team === parsed.team) s += 10;
    if(p.pos  === parsed.pos)  s += 5;
    if(p.name && p.name[0] && p.name[0].toUpperCase() === initialChar) s += 2;
    return { p, s };
  }).sort((a, b) => b.s - a.s);

  // Clear winner
  if(scored[0].s > (scored[1] ? scored[1].s : -1)) return scored[0].p;

  // Tied top scores: prefer one that's still available
  const top = scored.filter(x => x.s === scored[0].s);
  const undrafted = top.filter(x => !draftState.drafted.includes(x.p.id) && !isMine(x.p.id));
  if(undrafted.length === 1) return undrafted[0].p;
  return top[0].p;
}

function openSyncModal(){
  document.getElementById('syncModal').style.display = '';
  document.getElementById('syncResult').innerHTML = '';
  setTimeout(()=> document.getElementById('syncInput').focus(), 50);
}
function closeSyncModal(){
  document.getElementById('syncModal').style.display = 'none';
}

async function syncPasteFromClipboard(){
  try{
    const text = await navigator.clipboard.readText();
    if(!text || !text.trim()){
      alert('Clipboard is empty.  Run the bookmarklet on the Underdog draft page first.');
      return;
    }
    document.getElementById('syncInput').value = text;
  } catch(e){
    alert('Could not read clipboard (the browser may have blocked it).  Paste manually into the textarea instead — Ctrl+V or right-click → Paste.');
  }
}

// Shared by syncApplyDrafted() and the auto "mine" detector below \u2014 same
// matching pipeline either way, just different lines and different
// destination (drafted vs. mine).
function matchDraftedLines(lines){
  console.log('[CFB DEBUG] matchDraftedLines input lines:', lines);
  const nameIdx = buildNameIndex();
  const lastIdx = buildLastNameIndex();
  const matched   = [];
  const ambiguous = [];
  const unmatched = [];

  for(const line of lines){
    const parsed = parseDraftedLine(line);
    if(parsed){
      const player = matchParsedPick(parsed, lastIdx);
      if(player){ matched.push(player); continue; }
      unmatched.push(line);
      continue;
    }
    const k = normalizeName(line);
    if(!k){ continue; }
    const players = nameIdx[k];
    if(!players){
      unmatched.push(line);
    } else if(players.length === 1){
      matched.push(players[0]);
    } else {
      const undrafted = players.filter(p => !draftState.drafted.includes(p.id) && !isMine(p.id));
      if(undrafted.length === 1){
        matched.push(undrafted[0]);
      } else {
        ambiguous.push({line, options: players});
      }
    }
  }
  console.log('[CFB DEBUG] matched:', matched.map(p=>`${p.name} (${p.team||'?'}, ${p.pos||'?'})`));
  console.log('[CFB DEBUG] ambiguous:', ambiguous);
  console.log('[CFB DEBUG] unmatched:', unmatched);
  return {matched, ambiguous, unmatched};
}

// Auto-mine detector: underdog-watcher.js works out (via snake-draft math
// against your detected seat) which pick lines are yours, and sends just
// that subset here. We mark those players "mine" directly \u2014 same effect
// as the old manual \u2605 button, just automatic.
function markLinesAsMine(lines){
  if(!lines || lines.length === 0) return;
  const {matched} = matchDraftedLines(lines);
  let changed = false;
  matched.forEach(p=>{
    if(!isMine(p.id)){
      if(!draftState.mine.includes(p.id)) draftState.mine.push(p.id);
      draftState.drafted = draftState.drafted.filter(x=>x!==p.id);
      changed = true;
    }
  });
  if(changed){ saveState(); render(); }
}

function syncApplyDrafted(){
  const text = document.getElementById('syncInput').value;
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const resultEl = document.getElementById('syncResult');

  if(lines.length === 0){
    resultEl.innerHTML = `<span class="warn">Nothing to sync.</span>  Paste names first.`;
    return;
  }

  const {matched, ambiguous, unmatched} = matchDraftedLines(lines);

  // Apply: anything that isn't already drafted or yours
  let newDrafted = 0, alreadyMarked = 0;
  matched.forEach(p=>{
    if(draftState.drafted.includes(p.id) || isMine(p.id)){
      alreadyMarked++;
    } else {
      draftState.drafted.push(p.id);
      newDrafted++;
    }
  });
  saveState();
  render();

  // Result UI
  let html = '';
  html += `<span class="ok">✓ Marked ${newDrafted} new player${newDrafted!==1?'s':''} drafted</span>`;
  if(alreadyMarked > 0){
    html += `<span style="color:var(--dim)">  ·  ${alreadyMarked} already marked</span>`;
  }
  if(ambiguous.length > 0){
    html += `<div style="margin-top:8px"><span class="warn">${ambiguous.length} ambiguous</span> · need disambiguation:</div><ul>`;
    ambiguous.forEach(a=>{
      const opts = a.options.map(p => `${p.name} (${p.team || '—'})`).join(', ');
      html += `<li><b>${a.line}</b> → ${opts}</li>`;
    });
    html += `</ul>`;
  }
  if(unmatched.length > 0){
    html += `<div style="margin-top:8px"><span class="err">${unmatched.length} unmatched</span> · not in current pool:</div><ul>`;
    unmatched.forEach(u => { html += `<li>${u}</li>`; });
    html += `</ul>`;
  }
  resultEl.innerHTML = html;
}

document.getElementById('syncCancel').onclick = closeSyncModal;
document.getElementById('syncOverlay').onclick = closeSyncModal;
document.getElementById('syncPaste').onclick = syncPasteFromClipboard;
document.getElementById('syncApply').onclick = syncApplyDrafted;
// Esc closes the modal
document.addEventListener('keydown', e=>{
  if(e.key === 'Escape' && document.getElementById('syncModal').style.display !== 'none'){
    closeSyncModal();
  }
});

document.addEventListener('click', e=>{
  const un = e.target.closest('[data-unmine]');
  if(un){ e.stopPropagation(); unmine(un.dataset.unmine); return; }
  const star = e.target.closest('[data-star]');
  if(star){ e.stopPropagation(); toggleMine(star.dataset.star); return; }
  const queue = e.target.closest('[data-queue]');
  if(queue){ e.stopPropagation(); queuePlayer(queue.dataset.queue); return; }
  const row = e.target.closest('#dbody tr[data-id]');
  if(row){ toggleSelected(row.dataset.id); }
});

// Wire controls
document.querySelectorAll('#dposfilter .chip').forEach(c=>{
  c.onclick = ()=>{
    document.querySelectorAll('#dposfilter .chip').forEach(x=>x.classList.remove('on'));
    c.classList.add('on');
    posFilter = c.dataset.pos;
    render();
  };
});
document.getElementById('dsearch').oninput = e=>{ query = e.target.value; render(); };
document.querySelectorAll('.dtable thead th[data-k]').forEach(th=>{
  th.onclick = ()=>{
    const k = th.dataset.k;
    if(sortKey===k) sortDir *= -1;
    else { sortKey = k; sortDir = 1; }
    document.querySelectorAll('.dtable thead th .arr').forEach(a=>a.remove());
    th.insertAdjacentHTML('beforeend', `<span class="arr">${sortDir<0?'▼':'▲'}</span>`);
    render();
  };
});

// Injury ticker — reads injuries.json (produced by fetch_injuries.py) and
// renders a scrolling strip on the Draft Board.  Players in your Underdog pool
// are highlighted in amber with a star.  Hover pauses the scroll.
const INJURY_URL = (typeof window!=='undefined' && window.INJURY_URL) || './injuries.json';

function injEsc(s){
  return (s||'').replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
}
function injNorm(name){
  if(!name) return '';
  let n = name.toLowerCase().trim().replace(/[^a-z0-9 ]/g,'');
  let parts = n.split(/\s+/).filter(Boolean);
  if(parts.length && ['jr','sr','ii','iii','iv','v'].includes(parts[parts.length-1])) parts.pop();
  return parts.join('');
}
async function renderInjuryTicker(){
  const el = document.getElementById('injuryTicker');
  if(!el) return;
  let data;
  try{
    data = await (await fetch(INJURY_URL, {cache:'no-store'})).json();
  }catch(e){
    el.hidden = true;           // no file / offline → just hide it, no error noise
    return;
  }
  let items = (data && data.items) || [];
  if(!items.length){ el.hidden = true; return; }

  // Build a set of pool names so we can highlight + float relevant news first,
  // even if fetch_injuries.py wasn't run with pool scoping.
  const pool = new Set((BESTBALL.players||[]).map(p=>injNorm(p.name)));
  items.forEach(it=>{ it._pool = it.in_pool || pool.has(injNorm(it.player)); });
  items.sort((a,b)=>(b._pool?1:0)-(a._pool?1:0));

  const itemHTML = it=>{
    const pool = it._pool ? ' injury-item--pool' : '';
    const star = it._pool ? '<span class="injury-item__star">\u2605</span>' : '';
    const status = it.injury ? '<span class="injury-item__status">'+injEsc(it.injury)+'</span>' : '';
    return '<span class="injury-item'+pool+'">'+star+
      '<span class="injury-item__pos">'+injEsc(it.pos||'')+'</span>'+
      '<span class="injury-item__player">'+injEsc(it.player)+'</span>'+
      '<span class="injury-item__team">'+injEsc(it.team||'')+'</span>'+
      status+
      '<span class="injury-item__head">'+injEsc(it.headline||'')+'</span></span>';
  };

  const run = items.map(itemHTML).join('');
  let asof = '';
  if(data.as_of){
    const d = new Date(data.as_of);
    asof = isNaN(d) ? data.as_of : d.toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
  }
  const dur = Math.max(30, items.length * 7);  // slower with fewer items
  el.innerHTML =
    '<div class="injury-ticker__label"><span class="dot"></span>Injuries</div>'+
    '<div class="injury-ticker__viewport"><div class="injury-ticker__track" style="--injdur:'+dur+'s">'+run+run+'</div></div>'+
    (asof ? '<div class="injury-ticker__asof">as of '+injEsc(asof)+' \u00b7 RotoWire</div>' : '');
  el.hidden = false;
}

// ================ DATA LOAD + REFRESH ================
//
// Two things were wrong here and they compounded each other:
//
//  1. My Rank was whatever static value came down in bestball.json, so an
//     updated workbook moved `proj` but left `myRank` pointing at the old
//     my_rankings.csv order.  deriveRanks() below rebuilds rank from the
//     projections, matching what the site does.
//  2. bestball.json was fetched exactly once, when this iframe mounted.
//     Only the injury ticker had a refresh timer.  Leave an Underdog tab
//     open across a pipeline run and the panel kept serving whatever it
//     loaded at mount time, forever, with no way to reload short of
//     refreshing the whole draft page.
//
// A projection is only counted if it is a real number greater than zero -
// inject_my_proj.py writes null for players Bruce has no Final Pts for, and
// those must not be treated as a 0.0 projection and sorted to the bottom as
// though he actively ranked them last.
const MIN_PROJECTED = 25;
function hasMyProj(p){
  return typeof p.myProj === 'number' && isFinite(p.myProj) && p.myProj > 0;
}

function deriveRanks(){
  const players = BESTBALL.players || [];
  const projected = players.filter(hasMyProj);

  // Below the threshold the join probably failed (bad workbook path, stale
  // cache, --strict run).  Rebuilding rank off a handful of projections
  // would be worse than leaving the shipped ranks alone, so bail out.
  if (projected.length < MIN_PROJECTED){
    BESTBALL.ranksDerived = false;
    return;
  }

  projected.sort((a,b) =>
    (b.myProj - a.myProj) || ((a.adp ?? 9999) - (b.adp ?? 9999))
  );

  // Players with no projection but an existing rank keep their relative
  // ORDER, renumbered to sit below every projected player.  Players with
  // neither keep myRank null so the column still shows a dash for them
  // rather than inventing a rank for the deep pool.
  const carried = players
    .filter(p => !hasMyProj(p) && p.myRank != null)
    .sort((a,b) => (a.myRank - b.myRank) || ((a.adp ?? 9999) - (b.adp ?? 9999)));

  let r = 1;
  projected.forEach(p => { p.myRank = r++; });
  carried.forEach(p => { p.myRank = r++; });

  BESTBALL.ranksDerived = true;
}

function applyDataTransforms(){
  // Apply baked-in bye weeks.  BYE_WEEKS wins over bestball.json for any team
  // it covers — the full-name key is checked first because truncated abbrevs
  // like NORTH span multiple programs.  Values may be a single week or an
  // array (Week 0 teams have two byes).  Every player is normalized to a
  // `byes` array with `bye` kept as the first, so both code paths work.
  if (BESTBALL.players){
    BESTBALL.players.forEach(p=>{
      let arr = null;
      const ov = (p.teamFull != null && BYE_WEEKS[p.teamFull] != null) ? BYE_WEEKS[p.teamFull]
               : (p.team    != null && BYE_WEEKS[p.team]    != null) ? BYE_WEEKS[p.team]
               : null;
      if (ov != null){
        arr = Array.isArray(ov) ? ov.slice() : [ov];
      } else if (Array.isArray(p.byes) && p.byes.length){
        arr = p.byes.slice();
      } else if (p.bye != null){
        arr = [p.bye];
      }
      p.byes = arr || [];
      p.bye  = p.byes.length ? p.byes[0] : null;
    });
  }
  // Merge team logos from bestball.json (preferred source) over any baked-in
  // TEAM_LOGOS.  Logos in bestball.json refresh daily via make_bestball_json.py
  // so HTML updates don't blow them away.
  if (BESTBALL.teamLogos && typeof BESTBALL.teamLogos === 'object'){
    Object.assign(TEAM_LOGOS, BESTBALL.teamLogos);
  }
  deriveRanks();
}

function updateSrcInfo(){
  const src = document.getElementById('srcInfo');
  if(!src) return;
  const when = BESTBALL.updated ? new Date(BESTBALL.updated).toLocaleString([], {dateStyle:'medium', timeStyle:'short'}) : 'unknown';
  const tags = [];
  if (BESTBALL.ranksDerived)          tags.push('ranks from my proj');
  else if (BESTBALL.myRankingsJoined) tags.push('my ranks joined');
  if (Object.keys(BYE_WEEKS).length)  tags.push(`byes baked (${Object.keys(BYE_WEEKS).length})`);
  if (Object.keys(TEAM_LOGOS).length) tags.push(`logos (${Object.keys(TEAM_LOGOS).length})`);
  src.innerHTML = BESTBALL.count
    ? `<b>${BESTBALL.count}</b> players · Underdog · updated <b>${when}</b>` + (tags.length ? ' · ' + tags.join(' · ') : '')
    : `No data loaded.  Could not reach <b>${DATA_URL}</b>.`;
}

// Cache-busted on every call.  {cache:'no-store'} already bypasses the HTTP
// cache, but it does not stop a CDN edge from handing back a copy it cached
// before the last deploy, and that is exactly the window that matters when
// a push just went out mid-draft.
function dataUrlFresh(){
  return DATA_URL + (DATA_URL.includes('?') ? '&' : '?') + 't=' + Date.now();
}

// draftState stores player IDs.  The 5-minute refetch swaps the entire player
// set, so if a rebuild of bestball.json ever reassigns IDs, every drafted and
// mine marker would silently detach mid-draft.  Snapshot the names behind the
// marked IDs before the swap and re-resolve anything that no longer resolves.
function snapshotMarkedNames(){
  const map = {};
  (BESTBALL.players || []).forEach(p=>{
    if(isMine(p.id) || draftState.drafted.includes(p.id)) map[p.id] = normalizeName(p.name);
  });
  return map;
}

function remapDraftState(prevNames){
  const ids = new Set((BESTBALL.players || []).map(p=>p.id));
  const stale = [...draftState.mine, ...draftState.drafted].filter(id => !ids.has(id));
  if(stale.length === 0) return;

  const byName = {};
  (BESTBALL.players || []).forEach(p=>{
    const k = normalizeName(p.name);
    if(k && !byName[k]) byName[k] = p.id;
  });
  const fix = list => [...new Set(list.map(id=>{
    if(ids.has(id)) return id;
    const k = prevNames[id];
    return (k && byName[k]) ? byName[k] : null;
  }).filter(Boolean))];

  draftState.mine    = fix(draftState.mine);
  draftState.drafted = fix(draftState.drafted);
  if(draftState.selected && !ids.has(draftState.selected)) draftState.selected = null;
  saveState();
  console.warn(`[CFB] bestball.json reassigned ${stale.length} player ID(s) - draft state re-resolved by name.`);
}

let lastLoadedStamp = null;
let loading = false;

async function loadBestball(opts){
  const manual = opts && opts.manual;
  if (loading) return false;
  loading = true;
  const btn = document.getElementById('refreshBtn');
  if (btn) btn.classList.add('spin');
  try{
    const fetched = await (await fetch(dataUrlFresh(), {cache:'no-store'})).json();
    const changed = !lastLoadedStamp || fetched.updated !== lastLoadedStamp;
    const prevNames = snapshotMarkedNames();
    BESTBALL = fetched;
    lastLoadedStamp = fetched.updated || null;
    applyDataTransforms();
    remapDraftState(prevNames);
    updateSrcInfo();
    // Draft state lives in its own localStorage key, so a re-render here
    // never disturbs which players are marked drafted or yours.
    render();
    if (manual && !changed && btn) btn.title = 'Already current as of ' + (BESTBALL.updated || 'unknown');
    return true;
  }catch(e){
    console.warn('Could not load', DATA_URL, e);
    if (!BESTBALL.players || !BESTBALL.players.length){
      BESTBALL = {players:[], count:0, updated:""};
      updateSrcInfo();
    }
    return false;
  }finally{
    loading = false;
    if (btn) btn.classList.remove('spin');
  }
}

// Exposed so companion-storage-bridge.js can wait for the first load to
// finish before attempting any name-matching \u2014 without this, matching was
// racing against the fetch and silently failing whenever the fetch hadn't
// resolved yet, which explained inconsistent results between page loads.
window.BESTBALL_READY = (async()=>{
  await loadBestball();
  renderInjuryTicker();                       // draw the injury strip once data is in
  setInterval(renderInjuryTicker, 5*60*1000); // refresh every 5 min during a live draft

  // Pick up pipeline pushes without needing a draft-page reload.
  setInterval(()=> loadBestball(), 5*60*1000);

  // Coming back to the Underdog tab is the moment a stale panel is most
  // likely and most costly, so refetch then too, throttled so rapid tab
  // flipping during a draft doesn't hammer the CDN.
  let lastVisibleFetch = Date.now();
  document.addEventListener('visibilitychange', ()=>{
    if (document.visibilityState !== 'visible') return;
    if (Date.now() - lastVisibleFetch < 60*1000) return;
    lastVisibleFetch = Date.now();
    loadBestball();
  });

  const btn = document.getElementById('refreshBtn');
  if (btn) btn.onclick = ()=> loadBestball({manual:true});
})();

// Callable from the console if something looks stale mid-draft.
window.refreshBestball = ()=> loadBestball({manual:true});
