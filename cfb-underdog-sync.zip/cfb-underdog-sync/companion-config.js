  // Injected by the CFB → Underdog extension: pull data from the live
  // site rather than needing a local copy bundled into the extension.
  window.BESTBALL_URL = 'https://bestball-six.vercel.app/bestball.json';
