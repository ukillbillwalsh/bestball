// Loaded as the last <script> tag inside the bundled companion.html, which
// is itself running as a chrome-extension:// page (inside an iframe on the
// Underdog draft page). Because it's an extension page, it can call
// chrome.storage directly \u2014 no messaging bridge needed like a cross-origin
// content script would require.
//
// This intentionally goes through the SAME #syncInput / #syncApply UI path
// as the manual bookmarklet flow, rather than calling syncApplyDrafted()
// directly, so it keeps working even if the page's internal function names
// change later \u2014 only the element IDs need to stay stable.
//
// myNames (a subset of names, worked out by underdog-watcher.js via
// snake-draft math against your detected seat) gets marked as MINE
// specifically, via markLinesAsMine() \u2014 same result as the old manual
// \u2605 button, just automatic.
//
// IMPORTANT: everything here waits on window.BESTBALL_READY (set by
// companion-app.js) before doing any matching. Without that wait, this
// script was racing against the bestball.json fetch \u2014 if a pick came in
// before that fetch resolved, the player database was still empty and
// matching would silently fail (with no retry), which is what caused
// inconsistent results between page loads: whichever happened to finish
// first, by chance, decided whether matching worked that time.

(function () {
  const STORAGE_KEY = 'ud_picks_v1';
  // Same draftId the watcher put on the iframe URL.  Entries stamped with a
  // DIFFERENT draftId are leftovers from a previous draft and must never be
  // applied here — that was the one path by which an old draft's picks could
  // leak into a brand-new panel.
  const DRAFT_ID = new URLSearchParams(window.location.search).get('draftId') || '';
  let lastApplied = '';
  let lastMineApplied = '';

  function entryIsForThisDraft(entry) {
    if (!entry) return false;
    // Only reject on a definite mismatch; if either side has no draftId
    // (older watcher build, non-draft URL) keep the old permissive behavior.
    if (DRAFT_ID && entry.draftId && entry.draftId !== DRAFT_ID) return false;
    return true;
  }

  function applyNames(names) {
    const sig = names.join('|');
    if (sig === lastApplied || names.length === 0) return;

    const openBtn = document.getElementById('syncbtn');
    const input = document.getElementById('syncInput');
    const applyBtn = document.getElementById('syncApply');
    if (!input || !applyBtn) return; // page still initializing

    lastApplied = sig;
    if (openBtn) openBtn.click();
    input.value = names.join('\n');
    applyBtn.click();
  }

  function applyMine(myNames) {
    if (!myNames || myNames.length === 0) return;
    const sig = myNames.join('|');
    if (sig === lastMineApplied) return;
    if (typeof markLinesAsMine !== 'function') return; // page still initializing
    lastMineApplied = sig;
    markLinesAsMine(myNames);
  }

  async function ready() {
    // window.BESTBALL_READY is set synchronously by companion-app.js before
    // this script runs, but the fetch it wraps may still be in flight \u2014
    // awaiting it blocks until the player database is actually populated.
    try {
      if (window.BESTBALL_READY) await window.BESTBALL_READY;
    } catch (e) {
      /* companion-app.js already handles/logs fetch failures itself */
    }
  }

  async function checkStorage() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;
    await ready();
    chrome.storage.local.get(STORAGE_KEY, (res) => {
      const entry = res[STORAGE_KEY];
      if (!entryIsForThisDraft(entry)) return;
      if (entry.names) applyNames(entry.names);
      if (entry.myNames) applyMine(entry.myNames);
    });
  }

  checkStorage();

  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.onChanged.addListener(async (changes, area) => {
      if (area !== 'local' || !changes[STORAGE_KEY]) return;
      const entry = changes[STORAGE_KEY].newValue;
      if (!entryIsForThisDraft(entry)) return;
      await ready();
      if (entry.names) applyNames(entry.names);
      if (entry.myNames) applyMine(entry.myNames);
    });
  }
})();
