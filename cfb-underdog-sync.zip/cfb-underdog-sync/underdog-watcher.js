// Runs on underdogsports.com. Does two jobs:
//  1. Scrapes the draft board (same selector/regex as Bruce's bookmarklet)
//     any time the DOM changes, and writes the pick list to
//     chrome.storage.local.
//  2. Injects a small floating, draggable, resizable window with an
//     <iframe> pointing at the bundled companion.html \u2014 the whole tool
//     lives on this page, no second tab. Position/size persist across
//     reloads via chrome.storage.local.

(function () {
  const PICKS_KEY = 'ud_picks_v1';
  const PANEL_KEY = 'cfb_panel_state_v1';
  const PICK_LINE = /^[A-Z](?:\.[A-Z])*\.\s+.+?(QB|RB|WR|TE|K|D\/ST)[\s\-\u00b7]+[A-Z]+\s*$/;

  // Slimmed default: the compact companion layout is built for ~300px, so
  // the panel ships thin.  Drag the resize handle if you ever want it wider;
  // double-click the header to snap back to this.
  const DEFAULTS = { top: 16, left: null, width: 300, height: 500, collapsed: false };

  const DRAFT_ID = (location.pathname.match(/\/draft\/([a-f0-9-]+)/i) || [])[1] || '';

  // ---------- floating panel ----------

  function injectPanel() {
    if (document.getElementById('cfb-companion-panel')) return;
    chrome.storage.local.get(PANEL_KEY, (res) => {
      const saved = res[PANEL_KEY] || {};
      const state = Object.assign({}, DEFAULTS, saved);
      if (state.left == null) state.left = Math.max(16, window.innerWidth - state.width - 24);
      buildPanel(state);
    });
  }

  function buildPanel(state) {
    const panel = document.createElement('div');
    panel.id = 'cfb-companion-panel';
    panel.style.cssText = `
      position:fixed; top:${state.top}px; left:${state.left}px;
      width:${state.width}px; height:${state.height}px;
      min-width:240px; min-height:240px; max-width:96vw; max-height:92vh;
      z-index:2147483000; background:#0a0e16; border-radius:10px;
      overflow:hidden; resize:both; display:${state.collapsed ? 'none' : 'flex'};
      flex-direction:column; box-shadow:0 10px 34px rgba(0,0,0,.55);
      border:1px solid #23304a;
    `;

    const header = document.createElement('div');
    header.id = 'cfb-panel-header';
    header.style.cssText = `
      flex:0 0 auto; display:flex; align-items:center; justify-content:space-between;
      background:#131b2b; padding:7px 10px; cursor:grab; user-select:none;
      border-bottom:1px solid #23304a; font:700 11px/1 'IBM Plex Mono',monospace;
      color:#e8eef7; letter-spacing:.03em;
    `;
    const label = document.createElement('span');
    label.textContent = 'CFB DRAFT COMPANION \u00b7 drag \u00b7 dbl-click to reset size';
    const minBtn = document.createElement('button');
    minBtn.textContent = '\u2212';
    minBtn.title = 'Minimize';
    minBtn.style.cssText =
      'background:none;border:none;color:#8195b3;font-size:16px;line-height:1;' +
      'cursor:pointer;padding:0 4px;';
    header.appendChild(label);
    header.appendChild(minBtn);

    const iframe = document.createElement('iframe');
    iframe.id = 'cfb-companion-iframe';
    iframe.src = chrome.runtime.getURL('companion.html') + (DRAFT_ID ? '?draftId=' + encodeURIComponent(DRAFT_ID) : '');
    iframe.style.cssText = 'flex:1 1 auto; width:100%; border:none; display:block;';

    panel.appendChild(header);
    panel.appendChild(iframe);

    const pill = document.createElement('button');
    pill.id = 'cfb-companion-pill';
    pill.textContent = 'CFB';
    pill.style.cssText = `
      position:fixed; top:${state.top}px; left:${state.left}px;
      z-index:2147483001; background:#ff5a1f; color:#fff; border:none;
      font:700 12px 'IBM Plex Mono',monospace; padding:10px 14px; border-radius:20px;
      cursor:pointer; box-shadow:0 4px 14px rgba(0,0,0,.4);
      display:${state.collapsed ? 'block' : 'none'};
    `;

    document.documentElement.appendChild(panel);
    document.documentElement.appendChild(pill);

    function persist(extra) {
      const rect = panel.getBoundingClientRect();
      chrome.storage.local.set({
        [PANEL_KEY]: Object.assign(
          {
            top: rect.top,
            left: rect.left,
            width: rect.width,
            height: rect.height,
            collapsed: panel.style.display === 'none',
          },
          extra || {}
        ),
      });
    }

    // Drag panel via header
    let dragging = false, offsetX = 0, offsetY = 0;
    header.addEventListener('pointerdown', (e) => {
      dragging = true;
      header.setPointerCapture(e.pointerId);
      const rect = panel.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      header.style.cursor = 'grabbing';
    });
    header.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const rect = panel.getBoundingClientRect();
      let newLeft = Math.max(0, Math.min(window.innerWidth - 60, e.clientX - offsetX));
      let newTop = Math.max(0, Math.min(window.innerHeight - 40, e.clientY - offsetY));
      panel.style.left = newLeft + 'px';
      panel.style.top = newTop + 'px';
    });
    header.addEventListener('pointerup', () => {
      if (!dragging) return;
      dragging = false;
      header.style.cursor = 'grab';
      persist();
    });

    // Persist resizes (native CSS `resize:both` handle)
    new ResizeObserver(() => persist()).observe(panel);

    // Saved geometry sticks around forever, so once the panel has been
    // dragged large there's no way back to compact short of hand-resizing.
    // Double-clicking the header snaps it to the default size.
    header.addEventListener('dblclick', () => {
      panel.style.width = DEFAULTS.width + 'px';
      panel.style.height = DEFAULTS.height + 'px';
      persist();
    });

    // Minimize -> pill
    minBtn.addEventListener('click', () => {
      const rect = panel.getBoundingClientRect();
      panel.style.display = 'none';
      pill.style.top = rect.top + 'px';
      pill.style.left = rect.left + 'px';
      pill.style.display = 'block';
      persist({ collapsed: true, top: rect.top, left: rect.left });
    });

    // Drag pill; click (without drag) reopens panel
    let pillDragging = false, pillMoved = false, pOffsetX = 0, pOffsetY = 0;
    pill.addEventListener('pointerdown', (e) => {
      pillDragging = true;
      pillMoved = false;
      pill.setPointerCapture(e.pointerId);
      const rect = pill.getBoundingClientRect();
      pOffsetX = e.clientX - rect.left;
      pOffsetY = e.clientY - rect.top;
    });
    pill.addEventListener('pointermove', (e) => {
      if (!pillDragging) return;
      pillMoved = true;
      pill.style.left = e.clientX - pOffsetX + 'px';
      pill.style.top = e.clientY - pOffsetY + 'px';
    });
    pill.addEventListener('pointerup', () => {
      pillDragging = false;
    });
    pill.addEventListener('click', () => {
      if (pillMoved) {
        pillMoved = false;
        persist({ collapsed: true, top: parseFloat(pill.style.top), left: parseFloat(pill.style.left) });
        return;
      }
      panel.style.top = pill.style.top;
      panel.style.left = pill.style.left;
      pill.style.display = 'none';
      panel.style.display = 'flex';
      persist();
    });
  }

  // ---------- scrape + sync ----------

  // ---------- read picks straight from the board's own labels ----------
  //
  // Confirmed against real Underdog markup (a draftingCell button):
  //
  //   <button class="...draftingCell... ...userCell...">
  //     <div class="topHalf">
  //       <p class="roundAndPick">4.7|43</p>        round.pick | overall
  //     </div>
  //     <div class="bottomHalf">
  //       <p class="pickName">J. Scott</p>          name
  //       <div class="pickPos"><span>RB - NCST</span></div>   pos - team
  //     </div>
  //   </button>
  //
  // Two facts drive everything:
  //   1. The player name is SPLIT across pickName and pickPos, so we must
  //      read the two nodes and join them with a space to rebuild the
  //      "J. Scott RB - NCST" line the companion's matcher expects.  The
  //      concatenated textContent ("J. ScottRB - NCST") is fragile.
  //   2. Underdog tags every one of YOUR OWN pick cells with a "userCell"
  //      class (plus your avatar/username).  So your picks are simply the
  //      userCell cells - no seat detection, geometry, snake math, or column
  //      inference required.  All of that machinery was inferring what the
  //      DOM already labels, and getting it wrong past pick 1.

  // A drafting cell counts as a completed pick only once it has a name node.
  function hasPick(cell) {
    return !!cell.querySelector('[class*="pickName"]');
  }

  // Rebuild the "Initial. Last POS - TEAM" line from the two split nodes.
  function readCell(cell) {
    const nameEl = cell.querySelector('[class*="pickName"]');
    if (!nameEl) return null;
    const posEl = cell.querySelector('[class*="pickPos"]');
    const name = nameEl.textContent.trim();
    const pos = posEl ? posEl.textContent.trim() : '';
    const line = (name + ' ' + pos).replace(/\s+/g, ' ').trim();
    return line || null;
  }

  // Overall pick number ("4.7|43" -> 43), for chronological ordering.
  function overallOf(cell) {
    const rp = cell.querySelector('[class*="roundAndPick"]');
    if (!rp) return Infinity;
    const m = rp.textContent.replace(/\s+/g, '').match(/\|(\d+)/);
    if (m) return parseInt(m[1], 10);
    const m2 = rp.textContent.match(/(\d+)\.(\d+)/); // fall back to round.pick
    return m2 ? parseInt(m2[1], 10) * 1000 + parseInt(m2[2], 10) : Infinity;
  }

  function allCells() {
    return Array.from(document.querySelectorAll('[class*="draftingCell"]')).filter(hasPick);
  }
  function myCells() {
    return Array.from(document.querySelectorAll('[class*="userCell"]')).filter(hasPick);
  }

  function linesFrom(cells) {
    return cells
      .map((c) => ({ line: readCell(c), n: overallOf(c) }))
      .filter((o) => o.line && PICK_LINE.test(o.line))
      .sort((a, b) => a.n - b.n)
      .map((o) => o.line);
  }

  function scrapePicks() {
    return linesFrom(allCells());
  }

  let lastSig = '';
  let lastStrategy = 'none';
  function sync() {
    const names = scrapePicks();
    const myNames = linesFrom(myCells());
    const sig = names.join('|') + '##' + myNames.join('|');
    if (sig === lastSig) return;
    lastSig = sig;

    const strategy = myNames.length ? 'userCell' : (names.length ? 'userCell/empty' : 'none');
    lastStrategy = strategy;

    if (names.length && !myNames.length) {
      console.warn(
        '[CFB] Picks are on the board but none are tagged as yours yet. ' +
        'If you have already drafted, run window.__cfbDiag() and send the output.'
      );
    }

    console.log('[CFB] total picks=' + names.length, '| yours=' + myNames.length,
                '| strategy=' + strategy, myNames);

    // draftId travels with the pick list so the companion can refuse picks
    // scraped from a DIFFERENT draft.  Without it, opening a new draft
    // briefly replayed the previous draft's stored picks into the fresh
    // panel before the first rescrape overwrote them.
    chrome.storage.local.set({
      [PICKS_KEY]: { names, myNames, strategy, draftId: DRAFT_ID, updatedAt: Date.now() },
    });
  }

  // On-demand diagnostic.  Prints what the reader sees so any future markup
  // change can be diagnosed from real output rather than guessed at.  Dumps
  // enough structure that a single paste settles how the board is marked up:
  // in particular whether "userCell" is on every one of your picks or on a
  // single seat card.
  window.__cfbDiag = function () {
    const trunc = (el) => {
      if (!el) return null;
      const h = el.outerHTML || '';
      return h.length > 600 ? h.slice(0, 600) + ' …[truncated]' : h;
    };
    const withPickName = Array.from(document.querySelectorAll('[class*="pickName"]'));
    const userCellEls = Array.from(document.querySelectorAll('[class*="userCell"]'));
    const userCellsWithPick = userCellEls.filter((el) => el.querySelector('[class*="pickName"]'));
    const all = allCells();
    const mine = myCells();

    // A pick cell = the nearest ancestor of a pickName that looks like a cell.
    const firstPickCell = withPickName[0]
      ? (withPickName[0].closest('[class*="draftingCell"]') || withPickName[0].closest('button,[class*="Cell"],[class*="cell"]') || withPickName[0].parentElement)
      : null;

    const info = {
      lastStrategy,
      counts: {
        draftingCells: document.querySelectorAll('[class*="draftingCell"]').length,
        pickNameNodes: withPickName.length,
        userCellEls: userCellEls.length,
        userCellsContainingAPick: userCellsWithPick.length,
        allCells_read: all.length,
        myCells_read: mine.length,
      },
      // The decisive signal: if userCellEls is ~1 while pickNameNodes is many,
      // userCell marks your SEAT CARD, not each pick, and detection must key
      // off column/position instead.
      interpretation:
        userCellsWithPick.length > 1 ? 'userCell-per-pick (current logic OK)'
        : userCellEls.length >= 1 && withPickName.length > userCellsWithPick.length ? 'userCell looks like a SEAT CARD, not per-pick — needs column-based detection'
        : 'unclear — send the HTML below',
      myLines: linesFrom(mine),
      firstUserCell_html: trunc(userCellEls[0]),
      firstPickCell_html: trunc(firstPickCell),
      firstPickCell_parent_html: trunc(firstPickCell && firstPickCell.parentElement),
    };
    console.log('[CFB DIAG]\n' + JSON.stringify(info, null, 2));
    return info;
  };

  let debounceTimer = null;
  const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(sync, 400);
  });

  function start() {
    injectPanel();
    sync();
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
    });
    setInterval(sync, 3000); // fallback poll
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }

})();
