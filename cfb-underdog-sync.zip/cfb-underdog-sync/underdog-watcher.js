// Runs on underdogsports.com. Does two jobs:
//  1. Scrapes the draft board (same selector/regex as Bruce's bookmarklet)
//     any time the DOM changes, and writes the pick list to
//     chrome.storage.local.
//  2. Injects a small floating, draggable, resizable window with an
//     <iframe> pointing at the bundled companion.html \u2014 the whole tool
//     lives on this page, no second tab. Position/size persist across
//     reloads via chrome.storage.local.

(function () {
  const PICKS_KEY = 'ud_picks_v1';
  const PANEL_KEY = 'cfb_panel_state_v1';
  const PICK_LINE = /^[A-Z](?:\.[A-Z])*\.\s+.+?(QB|RB|WR|TE|K|D\/ST)[\s\-\u00b7]+[A-Z]+\s*$/;

  // Slimmed default: the compact companion layout is built for ~300px, so
  // the panel ships thin.  Drag the resize handle if you ever want it wider;
  // double-click the header to snap back to this.
  const DEFAULTS = { top: 16, left: null, width: 300, height: 500, collapsed: false };

  const DRAFT_ID = (location.pathname.match(/\/draft\/([a-f0-9-]+)/i) || [])[1] || '';

  // ---------- floating panel ----------

  function injectPanel() {
    if (document.getElementById('cfb-companion-panel')) return;
    chrome.storage.local.get(PANEL_KEY, (res) => {
      const saved = res[PANEL_KEY] || {};
      const state = Object.assign({}, DEFAULTS, saved);
      if (state.left == null) state.left = Math.max(16, window.innerWidth - state.width - 24);
      buildPanel(state);
    });
  }

  function buildPanel(state) {
    const panel = document.createElement('div');
    panel.id = 'cfb-companion-panel';
    panel.style.cssText = `
      position:fixed; top:${state.top}px; left:${state.left}px;
      width:${state.width}px; height:${state.height}px;
      min-width:240px; min-height:240px; max-width:96vw; max-height:92vh;
      z-index:2147483000; background:#0a0e16; border-radius:10px;
      overflow:hidden; resize:both; display:${state.collapsed ? 'none' : 'flex'};
      flex-direction:column; box-shadow:0 10px 34px rgba(0,0,0,.55);
      border:1px solid #23304a;
    `;

    const header = document.createElement('div');
    header.id = 'cfb-panel-header';
    header.style.cssText = `
      flex:0 0 auto; display:flex; align-items:center; justify-content:space-between;
      background:#131b2b; padding:7px 10px; cursor:grab; user-select:none;
      border-bottom:1px solid #23304a; font:700 11px/1 'IBM Plex Mono',monospace;
      color:#e8eef7; letter-spacing:.03em;
    `;
    const label = document.createElement('span');
    label.textContent = 'CFB DRAFT COMPANION \u00b7 drag \u00b7 dbl-click to reset size';
    const minBtn = document.createElement('button');
    minBtn.textContent = '\u2212';
    minBtn.title = 'Minimize';
    minBtn.style.cssText =
      'background:none;border:none;color:#8195b3;font-size:16px;line-height:1;' +
      'cursor:pointer;padding:0 4px;';
    header.appendChild(label);
    header.appendChild(minBtn);

    const iframe = document.createElement('iframe');
    iframe.id = 'cfb-companion-iframe';
    iframe.src = chrome.runtime.getURL('companion.html') + (DRAFT_ID ? '?draftId=' + encodeURIComponent(DRAFT_ID) : '');
    iframe.style.cssText = 'flex:1 1 auto; width:100%; border:none; display:block;';

    panel.appendChild(header);
    panel.appendChild(iframe);

    const pill = document.createElement('button');
    pill.id = 'cfb-companion-pill';
    pill.textContent = 'CFB';
    pill.style.cssText = `
      position:fixed; top:${state.top}px; left:${state.left}px;
      z-index:2147483001; background:#ff5a1f; color:#fff; border:none;
      font:700 12px 'IBM Plex Mono',monospace; padding:10px 14px; border-radius:20px;
      cursor:pointer; box-shadow:0 4px 14px rgba(0,0,0,.4);
      display:${state.collapsed ? 'block' : 'none'};
    `;

    document.documentElement.appendChild(panel);
    document.documentElement.appendChild(pill);

    function persist(extra) {
      const rect = panel.getBoundingClientRect();
      chrome.storage.local.set({
        [PANEL_KEY]: Object.assign(
          {
            top: rect.top,
            left: rect.left,
            width: rect.width,
            height: rect.height,
            collapsed: panel.style.display === 'none',
          },
          extra || {}
        ),
      });
    }

    // Drag panel via header
    let dragging = false, offsetX = 0, offsetY = 0;
    header.addEventListener('pointerdown', (e) => {
      dragging = true;
      header.setPointerCapture(e.pointerId);
      const rect = panel.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      header.style.cursor = 'grabbing';
    });
    header.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const rect = panel.getBoundingClientRect();
      let newLeft = Math.max(0, Math.min(window.innerWidth - 60, e.clientX - offsetX));
      let newTop = Math.max(0, Math.min(window.innerHeight - 40, e.clientY - offsetY));
      panel.style.left = newLeft + 'px';
      panel.style.top = newTop + 'px';
    });
    header.addEventListener('pointerup', () => {
      if (!dragging) return;
      dragging = false;
      header.style.cursor = 'grab';
      persist();
    });

    // Persist resizes (native CSS `resize:both` handle)
    new ResizeObserver(() => persist()).observe(panel);

    // Saved geometry sticks around forever, so once the panel has been
    // dragged large there's no way back to compact short of hand-resizing.
    // Double-clicking the header snaps it to the default size.
    header.addEventListener('dblclick', () => {
      panel.style.width = DEFAULTS.width + 'px';
      panel.style.height = DEFAULTS.height + 'px';
      persist();
    });

    // Minimize -> pill
    minBtn.addEventListener('click', () => {
      const rect = panel.getBoundingClientRect();
      panel.style.display = 'none';
      pill.style.top = rect.top + 'px';
      pill.style.left = rect.left + 'px';
      pill.style.display = 'block';
      persist({ collapsed: true, top: rect.top, left: rect.left });
    });

    // Drag pill; click (without drag) reopens panel
    let pillDragging = false, pillMoved = false, pOffsetX = 0, pOffsetY = 0;
    pill.addEventListener('pointerdown', (e) => {
      pillDragging = true;
      pillMoved = false;
      pill.setPointerCapture(e.pointerId);
      const rect = pill.getBoundingClientRect();
      pOffsetX = e.clientX - rect.left;
      pOffsetY = e.clientY - rect.top;
    });
    pill.addEventListener('pointermove', (e) => {
      if (!pillDragging) return;
      pillMoved = true;
      pill.style.left = e.clientX - pOffsetX + 'px';
      pill.style.top = e.clientY - pOffsetY + 'px';
    });
    pill.addEventListener('pointerup', () => {
      pillDragging = false;
    });
    pill.addEventListener('click', () => {
      if (pillMoved) {
        pillMoved = false;
        persist({ collapsed: true, top: parseFloat(pill.style.top), left: parseFloat(pill.style.left) });
        return;
      }
      panel.style.top = pill.style.top;
      panel.style.left = pill.style.left;
      pill.style.display = 'none';
      panel.style.display = 'flex';
      persist();
    });
  }

  // ---------- scrape + sync ----------

  // ---------- read picks straight from the board's own labels ----------
  //
  // Confirmed against real Underdog markup (a draftingCell button):
  //
  //   <button class="...draftingCell... ...userCell...">
  //     <div class="topHalf">
  //       <p class="roundAndPick">4.7|43</p>        round.pick | overall
  //     </div>
  //     <div class="bottomHalf">
  //       <p class="pickName">J. Scott</p>          name
  //       <div class="pickPos"><span>RB - NCST</span></div>   pos - team
  //     </div>
  //   </button>
  //
  // Two facts drive everything:
  //   1. The player name is SPLIT across pickName and pickPos, so we must
  //      read the two nodes and join them with a space to rebuild the
  //      "J. Scott RB - NCST" line the companion's matcher expects.  The
  //      concatenated textContent ("J. ScottRB - NCST") is fragile.
  //   2. Underdog tags every one of YOUR OWN pick cells with a "userCell"
  //      class (plus your avatar/username).  So your picks are simply the
  //      userCell cells - no seat detection, geometry, snake math, or column
  //      inference required.  All of that machinery was inferring what the
  //      DOM already labels, and getting it wrong past pick 1.

  // A drafting cell counts as a completed pick only once it has a name node.
  function hasPick(cell) {
    return !!cell.querySelector('[class*="pickName"]');
  }

  // Rebuild the "Initial. Last POS - TEAM" line from the two split nodes.
  function readCell(cell) {
    const nameEl = cell.querySelector('[class*="pickName"]');
    if (!nameEl) return null;
    const posEl = cell.querySelector('[class*="pickPos"]');
    const name = nameEl.textContent.trim();
    const pos = posEl ? posEl.textContent.trim() : '';
    const line = (name + ' ' + pos).replace(/\s+/g, ' ').trim();
    return line || null;
  }

  // Overall pick number ("4.7|43" -> 43), for chronological ordering.
  function overallOf(cell) {
    const rp = cell.querySelector('[class*="roundAndPick"]');
    if (!rp) return Infinity;
    const m = rp.textContent.replace(/\s+/g, '').match(/\|(\d+)/);
    if (m) return parseInt(m[1], 10);
    const m2 = rp.textContent.match(/(\d+)\.(\d+)/); // fall back to round.pick
    return m2 ? parseInt(m2[1], 10) * 1000 + parseInt(m2[2], 10) : Infinity;
  }

  function allCells() {
    return Array.from(document.querySelectorAll('[class*="draftingCell"]')).filter(hasPick);
  }
  function myCells() {
    return Array.from(document.querySelectorAll('[class*="userCell"]')).filter(hasPick);
  }

  function linesFrom(cells) {
    return cells
      .map((c) => ({ line: readCell(c), n: overallOf(c) }))
      .filter((o) => o.line && PICK_LINE.test(o.line))
      .sort((a, b) => a.n - b.n)
      .map((o) => o.line);
  }

  function scrapePicks() {
    return linesFrom(allCells());
  }

  let lastSig = '';
  let lastStrategy = 'none';
  function sync() {
    const names = scrapePicks();
    const myNames = linesFrom(myCells());
    const sig = names.join('|') + '##' + myNames.join('|');
    if (sig === lastSig) return;
    lastSig = sig;

    const strategy = myNames.length ? 'userCell' : (names.length ? 'userCell/empty' : 'none');
    lastStrategy = strategy;

    if (names.length && !myNames.length) {
      console.warn(
        '[CFB] Picks are on the board but none are tagged as yours yet. ' +
        'If you have already drafted, run window.__cfbDiag() and send the output.'
      );
    }

    console.log('[CFB] total picks=' + names.length, '| yours=' + myNames.length,
                '| strategy=' + strategy, myNames);

    // draftId travels with the pick list so the companion can refuse picks
    // scraped from a DIFFERENT draft.  Without it, opening a new draft
    // briefly replayed the previous draft's stored picks into the fresh
    // panel before the first rescrape overwrote them.
    chrome.storage.local.set({
      [PICKS_KEY]: { names, myNames, strategy, draftId: DRAFT_ID, updatedAt: Date.now() },
    });
  }

  // On-demand diagnostic.  Prints what the reader sees so any future markup
  // change can be diagnosed from real output rather than guessed at.  Dumps
  // enough structure that a single paste settles how the board is marked up:
  // in particular whether "userCell" is on every one of your picks or on a
  // single seat card.
  window.__cfbDiag = function () {
    const trunc = (el) => {
      if (!el) return null;
      const h = el.outerHTML || '';
      return h.length > 600 ? h.slice(0, 600) + ' …[truncated]' : h;
    };
    const withPickName = Array.from(document.querySelectorAll('[class*="pickName"]'));
    const userCellEls = Array.from(document.querySelectorAll('[class*="userCell"]'));
    const userCellsWithPick = userCellEls.filter((el) => el.querySelector('[class*="pickName"]'));
    const all = allCells();
    const mine = myCells();

    // A pick cell = the nearest ancestor of a pickName that looks like a cell.
    const firstPickCell = withPickName[0]
      ? (withPickName[0].closest('[class*="draftingCell"]') || withPickName[0].closest('button,[class*="Cell"],[class*="cell"]') || withPickName[0].parentElement)
      : null;

    const info = {
      lastStrategy,
      counts: {
        draftingCells: document.querySelectorAll('[class*="draftingCell"]').length,
        pickNameNodes: withPickName.length,
        userCellEls: userCellEls.length,
        userCellsContainingAPick: userCellsWithPick.length,
        allCells_read: all.length,
        myCells_read: mine.length,
      },
      // The decisive signal: if userCellEls is ~1 while pickNameNodes is many,
      // userCell marks your SEAT CARD, not each pick, and detection must key
      // off column/position instead.
      interpretation:
        userCellsWithPick.length > 1 ? 'userCell-per-pick (current logic OK)'
        : userCellEls.length >= 1 && withPickName.length > userCellsWithPick.length ? 'userCell looks like a SEAT CARD, not per-pick — needs column-based detection'
        : 'unclear — send the HTML below',
      myLines: linesFrom(mine),
      firstUserCell_html: trunc(userCellEls[0]),
      firstPickCell_html: trunc(firstPickCell),
      firstPickCell_parent_html: trunc(firstPickCell && firstPickCell.parentElement),
    };
    console.log('[CFB DIAG]\n' + JSON.stringify(info, null, 2));
    return info;
  };

  let debounceTimer = null;
  const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(sync, 400);
  });

  function start() {
    injectPanel();
    sync();
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
    });
    setInterval(sync, 3000); // fallback poll
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
  // ---------- queue-a-player (message from the companion iframe) ----------

  function normalizeForMatch(s) {
    return (s || '')
      .toLowerCase()
      .replace(/[^a-z0-9 ]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // player = { name, lastName, team, pos } sent over from the companion
  // iframe, where it was already resolved unambiguously against the real
  // player pool. Here we just need to find ITS row among what Underdog
  // has rendered \u2014 requiring last name AND (team OR position) to agree
  // avoids mismatching same-surname players (Smith, Jr/Sr, etc).
  function rowMatchesPlayer(rowText, player) {
    const rowN = normalizeForMatch(rowText);

    // Primary check: Underdog's own available-players list shows full
    // names directly (e.g. "Jadan Baugh"), so match on that first \u2014
    // it's unique enough on its own and sidesteps any risk of team
    // abbreviations being formatted differently between our data source
    // and Underdog's (which was silently breaking specific players whose
    // abbreviation didn't happen to agree between the two).
    const fullName = normalizeForMatch(player.name || '');
    if (fullName && rowN.includes(fullName)) return true;

    // Fallback for edge cases (nickname/short-name differences, etc.)
    const last = normalizeForMatch(player.lastName || '');
    if (!last || !rowN.includes(last)) return false;
    if (player.team && rowN.includes(normalizeForMatch(player.team))) return true;
    if (player.pos && rowN.includes(normalizeForMatch(player.pos))) return true;
    return false;
  }

  // A bare .click() only fires a 'click' event. Virtualized-list rows like
  // this one often react to pointerdown/mousedown instead (common for
  // responsiveness), so a plain .click() can silently do nothing useful.
  // This dispatches the full realistic sequence a real mouse click produces.
  function simulateRealClick(el) {
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const base = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };
    const pointerBase = Object.assign({ pointerId: 1, pointerType: 'mouse', isPrimary: true }, base);
    el.dispatchEvent(new PointerEvent('pointerdown', pointerBase));
    el.dispatchEvent(new MouseEvent('mousedown', base));
    el.dispatchEvent(new PointerEvent('pointerup', pointerBase));
    el.dispatchEvent(new MouseEvent('mouseup', base));
    el.dispatchEvent(new MouseEvent('click', base));
  }

  // Handles the case where the player's card is ALREADY expanded (e.g.
  // right after removing them, their card stays open) \u2014 in that state the
  // collapsed-row wrapper this function normally looks for isn't there in
  // the same shape, so searching for it fails silently. This checks for an
  // open card carrying the Queue/Remove button directly, scoped to a
  // reasonably-sized ancestor so it doesn't match the whole page by
  // accident.
  function currentActionButtons() {
    return Array.from(document.querySelectorAll('button[data-testid="button"]')).filter((el) =>
      /^(queue|remove)$/i.test((el.textContent || '').trim())
    );
  }

  function findAndClickQueueButton(player) {
    const wrappers = document.querySelectorAll('[data-testid="player-cell-wrapper"]');
    for (const btn of wrappers) {
      const cell = btn.closest('[class*="playerCell"]') || btn.parentElement;
      const infoEl = cell && cell.querySelector('[class*="playerInfo"]');
      const text = (infoEl ? infoEl.textContent : (cell ? cell.textContent : '')).trim();
      if (text && rowMatchesPlayer(text, player)) {
        simulateRealClick(btn);
        return true;
      }
    }
    return false;
  }

  let toastEl = null;
  let toastTimer = null;
  function showToast(msg) {
    if (!toastEl || !document.documentElement.contains(toastEl)) {
      toastEl = document.createElement('div');
      toastEl.id = 'cfb-toast';
      toastEl.style.cssText = `
        position:fixed; bottom:16px; right:16px; z-index:2147483002;
        background:#131b2b; color:#e8eef7; font:600 12px/1.4 monospace;
        padding:8px 12px; border-radius:6px; border:1px solid #2e3e5c;
        box-shadow:0 4px 14px rgba(0,0,0,.4); max-width:320px;
      `;
      document.documentElement.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      if (toastEl) toastEl.remove();
      toastEl = null;
    }, 4000);
  }

  // Step 1 above only expands/selects the row \u2014 confirmed by real testing,
  // not just assumption, that this never actually toggles the queue on its
  // own. The real "add to queue" control is a separate button that appears
  // once the card is expanded; its data-testid is generic ("button", shared
  // with the "Draft" button next to it) so we match it by its actual text
  // AND by which player's row it belongs to \u2014 a global "first match wins"
  // search was clicking a leftover open card's button instead of the one
  // we actually just expanded, if more than one card was open at once.
  async function clickQueueActionButton(player, before) {
    // Give React a moment to render the expanded card's action buttons.
    for (let i = 0; i < 10; i++) {
      const current = currentActionButtons();
      const fresh = current.filter((el) => !before.has(el));

      if (fresh.length === 1) {
        // Exactly one new button appeared since we clicked to expand \u2014
        // it's guaranteed to belong to the row we just opened, no content
        // matching needed (and safer than matching, since this button
        // isn't reliably scoped inside a playerCell-classed ancestor the
        // way the collapsed star icon is).
        const el = fresh[0];
        const action = (el.textContent || '').trim().toLowerCase();
        simulateRealClick(el);
        return action;
      }
      if (fresh.length > 1) {
        // More than one appeared somehow \u2014 fall back to matching by
        // player identity among just the new ones.
        for (const el of fresh) {
          const cell = el.closest('[class*="playerCell"]');
          const infoEl = cell && cell.querySelector('[class*="playerInfo"]');
          const text = (infoEl ? infoEl.textContent : (cell ? cell.textContent : '')).trim();
          if (text && rowMatchesPlayer(text, player)) {
            const action = (el.textContent || '').trim().toLowerCase();
            simulateRealClick(el);
            return action;
          }
        }
      }
      await new Promise((r) => setTimeout(r, 100));
    }
    return null;
  }

  // Tracks which player's card WE last opened, by a stable identity key
  // (last name + team). This replaces trying to detect "is this player's
  // card already open" by reading page content \u2014 that approach kept
  // producing false positives (matching incidental nearby text, like a
  // suggested-players list) rather than the actual open card. Since we're
  // the ones who opened it, we can just remember that with certainty
  // instead of re-inferring it from the DOM every time.
  let openPlayerKey = null;
  function playerKey(p) {
    return `${(p.lastName || '').toLowerCase()}|${(p.team || '').toLowerCase()}`;
  }

  async function queuePlayerByName(player) {
    const key = playerKey(player);

    if (key === openPlayerKey) {
      // We believe this exact player's card is the one we ourselves left
      // open (e.g. right after adding/removing them) \u2014 whatever
      // Queue/Remove button exists right now must be theirs, no content
      // matching needed.
      const candidates = currentActionButtons();
      if (candidates.length >= 1) {
        const el = candidates[0];
        const action = (el.textContent || '').trim().toLowerCase();
        simulateRealClick(el);
        showToast(
          action === 'queue'
            ? `CFB sync: queued ${player.name}`
            : `CFB sync: removed ${player.name} from queue`
        );
        return;
      }
      // Nothing found despite our tracking saying it should be open \u2014
      // fall through to the normal flow below rather than giving up.
    }

    // Different player than whatever we last opened (or nothing tracked)
    // \u2014 go through the normal expand flow. Clicking a new row naturally
    // closes whatever Underdog had open before, and the before/after
    // snapshot below correctly isolates the newly-appeared button
    // regardless of what disappeared.
    const beforeSnapshot = new Set(currentActionButtons());
    if (findAndClickQueueButton(player)) {
      const action = await clickQueueActionButton(player, beforeSnapshot);
      if (action) openPlayerKey = key;
      if (action === 'queue') {
        showToast(`CFB sync: queued ${player.name}`);
      } else if (action === 'remove') {
        showToast(`CFB sync: removed ${player.name} from queue`);
      } else {
        showToast(`CFB sync: expanded ${player.name} but couldn't find the Queue/Remove button`);
      }
      return;
    }
    // Not currently rendered \u2014 the list is virtualized, so scroll through
    // it looking for the player. Bounded two ways so this can never run
    // away: a fixed number of steps (so a huge scrollHeight can't turn
    // into hundreds of iterations) and a hard wall-clock timeout.
    const grid = document.querySelector('[role="grid"]');
    if (!grid) {
      showToast(`CFB sync: couldn't find the player list to search`);
      return;
    }
    const maxScroll = grid.scrollHeight;
    const startTop = grid.scrollTop;
    const MAX_STEPS = 20;
    const MAX_MS = 6000;
    // Capped at one viewport's height \u2014 a bigger step could jump past rows
    // that never got rendered in between (virtualization only renders
    // what's actually in view), silently skipping them. Accepting partial
    // coverage within the time budget is the safer tradeoff.
    const stepPx = grid.clientHeight || 400;
    const deadline = Date.now() + MAX_MS;

    let found = false;
    let action = null;
    for (let pos = 0, steps = 0; pos <= maxScroll && steps < MAX_STEPS && Date.now() < deadline; pos += stepPx, steps++) {
      grid.scrollTop = pos;
      await new Promise((r) => setTimeout(r, 150));
      const beforeSnapshot = new Set(currentActionButtons());
      if (findAndClickQueueButton(player)) {
        found = true;
        action = await clickQueueActionButton(player, beforeSnapshot);
        if (action) openPlayerKey = key;
        break;
      }
    }
    grid.scrollTop = startTop;
    showToast(
      !found
        ? `CFB sync: couldn't find ${player.name} in the list`
        : action === 'queue'
        ? `CFB sync: queued ${player.name}`
        : action === 'remove'
        ? `CFB sync: removed ${player.name} from queue`
        : `CFB sync: expanded ${player.name} but couldn't find the Queue/Remove button`
    );
  }

  window.addEventListener('message', (e) => {
    if (!e.data || e.data.type !== 'cfb-queue-player' || !e.data.name) return;
    queuePlayerByName({
      name: e.data.name,
      lastName: e.data.lastName || e.data.name.split(' ').pop(),
      team: e.data.team,
      pos: e.data.pos,
    });
  });

})();
